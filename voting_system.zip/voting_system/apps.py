from django.apps import AppConfig


class VotingSystemConfig(AppConfig):
    name = 'voting_system'
